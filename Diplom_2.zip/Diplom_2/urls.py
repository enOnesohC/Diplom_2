class URLS:
    URL_CREATE_USER = "https://stellarburgers.nomoreparties.site/api/auth/register"
    URL_AUTHORIZATION = "https://stellarburgers.nomoreparties.site/api/auth/login"
    URL_DELETE_USER = "https://stellarburgers.nomoreparties.site/api/auth/user"
    URL_CREATE_ORDER = "https://stellarburgers.nomoreparties.site/api/ingredients"
    URL_GET_ORDERS_USER = "https://stellarburgers.nomoreparties.site/api/orders"
